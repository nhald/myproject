<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
if(isset($_POST['submit']))
{
$recordfname=$_POST['firstname'];
$recordmname=$_POST['middlename'];
$recordlname=$_POST['lastname'];
$gender=$_POST['gender']; 
$brgname=$_POST['brg'];
$dob=$_POST['dob'];
$doq=$_POST['doq']; 
$status=$_POST['status'];
$contnum1=$_POST['contnum1'];
$cont_person=$_POST['cont_person'];
$placevisited=$_POST['placevisited'];
$vaccinated=$_POST['vaccinated']; 
$variant=$_POST['variant']; 

/****
for ($i=0; $i<count($fname); $i++)
{
	if($fname[$i]!="" && $adress[$i]!="" && $contnum[$i]!="" && $relation[$i]!="")
	{
		$sqll="INSERT INTO  tblrecord2(Fname,Contnum,Adress,Relationship) VALUES(:fname,:adress,:contnum,:relation)";
		$queryy = $dbh->prepare($sqll);
		$queryy->bindParam(':fname',$fname[$i],PDO::PARAM_STR);
		$queryy->bindParam(':adress',$adress[$i],PDO::PARAM_STR);
		$queryy->bindParam(':contnum',$contnum[$i],PDO::PARAM_STR);
		$queryy->bindParam(':relation',$relation[$i],PDO::PARAM_STR);		
		$queryy->execute();
	}
}	

for ($i=0; $i<count($placevisited); $i++)
{
	if($placevisited[$i]!="")
	{
		$sqll2="INSERT INTO  placevisited(PlaceVisit) VALUES(:placevisited)";
		$queryy2 = $dbh->prepare($sqll2);
		$queryy2->bindParam(':placevisited',$placevisited[$i],PDO::PARAM_STR);
		$queryy2->execute();

	}
}
****/

$sql="INSERT INTO  tblrecord(RecordFname,RecordMname,RecordLname,Gender,BrgName,DOB,DOQ,Status,ContactNum,Contact_Person,Place_Visited,Vaccinated,Variant) VALUES(:recordfname,:recordmname,:recordlname,:gender,:brgname,:dob,:doq,:status,:contnum1,:cont_person,:placevisited,:vaccinated,:variant)";
$query = $dbh->prepare($sql);
$query->bindParam(':recordfname',$recordfname,PDO::PARAM_STR);
$query->bindParam(':recordmname',$recordmname,PDO::PARAM_STR);
$query->bindParam(':recordlname',$recordlname,PDO::PARAM_STR);
$query->bindParam(':gender',$gender,PDO::PARAM_STR);
$query->bindParam(':brgname',$brgname,PDO::PARAM_STR);
$query->bindParam(':dob',$dob,PDO::PARAM_STR);
$query->bindParam(':doq',$doq,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->bindParam(':contnum1',$contnum1,PDO::PARAM_STR);
$query->bindParam(':cont_person',$cont_person,PDO::PARAM_STR);
$query->bindParam(':placevisited',$placevisited,PDO::PARAM_STR);
$query->bindParam(':vaccinated',$vaccinated,PDO::PARAM_STR);
$query->bindParam(':variant',$variant,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{

   echo"<script>
      // The function below will start the confirmation dialog

        let confirmAction = confirm('DATA SAVED!! Do you want to input another record?');
        if (confirmAction) {
          document.location = 'add-record.php';
        } else {
          document.location = 'dashboard.php';
        
      }
    </script>";
}
else 
{
$error="Something went wrong. Please try again";
}

}
?>
			<script src="js/scripted.js"></script>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    	<meta name="viewport" content="width=device-width, initial-scale=1">
        <title>TAORS Admin< </title>
        <link rel="stylesheet" href="css/bootstrap.min.css" media="screen" >
        <link rel="stylesheet" href="css/font-awesome.min.css" media="screen" >
        <link rel="stylesheet" href="css/animate-css/animate.min.css" media="screen" >
        <link rel="stylesheet" href="css/lobipanel/lobipanel.min.css" media="screen" >
        <link rel="stylesheet" href="css/prism/prism.css" media="screen" >
        <link rel="stylesheet" href="css/select2/select2.min.css" >
        <link rel="stylesheet" href="css/add.css" >
        <link rel="stylesheet" href="css/main.css" media="screen" >		
        <script src="js/modernizr/modernizr.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		
    </head>
    <body class="top-navbar-fixed">
        <div class="main-wrapper">

            <!-- ========== TOP NAVBAR ========== -->
  <?php include('includes/topbar2.php');?> 
            <!-- ========== WRAPPER FOR BOTH SIDEBARS & MAIN CONTENT ========== -->
            <div class="content-wrapper">
                <div class="content-container">

                    <!-- ========== LEFT SIDEBAR ========== -->

                    <!-- /.left-sidebar -->

                    <div class="main-page">

                     <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title">Add Record Information</h2>
                                
                                </div>
                                
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li><a href="dashboard.php"><i class="fa fa-home"></i> Home</a></li>
                                
                                        <li class="active">Information</li>
                                    </ul>
                                </div>
                             
                            </div>
                            <!-- /.row -->
                        </div>
                        <div class="container-fluid">
                           
                        <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5>Fill the Record Information</h5>
                                                </div>
                                            </div>
                                            <div class="panel-body">
<?php if($msg){?>
<div class="alert alert-success left-icon-alert" role="alert">
 <strong>Well done!</strong><?php echo htmlentities($msg); ?>
 </div><?php } 
else if($error){?>
    <div class="alert alert-danger left-icon-alert" role="alert">
                                            <strong>Oh snap!</strong> <?php echo htmlentities($error); ?>
                                        </div>
                                        <?php } ?>
                                                <form class="form-horizontal" method="post">

<div class="form-group">
<label for="default" class="col-sm-2 control-label">First Name</label>
<div class="col-sm-10">
<input type="text" name="firstname" class="form-control" id="firstname" required="required" autocomplete="off">
</div>
</div>

<div class="form-group">
<label for="default" class="col-sm-2 control-label">Middle Name</label>
<div class="col-sm-10">
<input type="text" name="middlename" class="form-control" id="middlename" required="required" autocomplete="off">
</div>
</div>

<div class="form-group">
<label for="default" class="col-sm-2 control-label">Last Name</label>
<div class="col-sm-10">
<input type="text" name="lastname" class="form-control" id="lastname" required="required" autocomplete="off">
</div>
</div>

	
<div class="form-group">
<label for="default" class="col-sm-2 control-label">Gender</label>
<div class="col-sm-10">
<input type="radio" name="gender" value="Male" required="required" checked=""> Male <input type="radio" name="gender" value="Female" required="required"> Female 
</div>
</div>


<div class="form-group">
<label for="default" class="col-sm-2 control-label">Contact Number</label>
<div class="col-sm-10">
<input type="text" onkeypress="return isNumberKey(event)" name="contnum1" class="form-control" id="contnum1" required="required" autocomplete="off" maxlength = "11" placeholder="e.g 09123456789">
</div>
</div>

<script>
function isNumberKey(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode
	if (charCode > 31 && (charCode < 48 || charCode > 57))
	return false;

	return true;
}
</script>

                                                    <div class="form-group">
                                                        <label for="default" class="col-sm-2 control-label">Resident</label>
                                                        <div class="col-sm-10">
 <select name="brg" class="form-control" id="default" required="required">
<option value="">Select Baranngay</option>
<?php $sql = "SELECT * from tblclasses";
$query = $dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
foreach($results as $result)
{   ?>
<option value="<?php echo htmlentities($result->BaranggayName); ?>"><?php echo htmlentities($result->BaranggayName); ?>&nbsp</option>
<?php }} ?>
 </select>
                                                        </div>
                                                    </div>

<div class="form-group">
                                                        <label for="date" class="col-sm-2 control-label">Date of Birth</label>
                                                        <div class="col-sm-10">
                                                            <input type="date"  name="dob" class="form-control" id="date">
                                                        </div>
                                                    </div>
													
<div class="form-group">
                                                        <label for="date" class="col-sm-2 control-label">Date Quarantined</label>
                                                        <div class="col-sm-10">
                                                            <input type="date"  name="doq" class="form-control" id="date">
                                                        </div>
                                                    </div>
 

<div class="form-group">
					<label for="default" class="col-sm-2 control-label">Place Visited</label>
							<div class="col-sm-10">
								<textarea rows="3" cols="30" type="text" name="placevisited" class="form-control" id="placevisited" autocomplete="off"></textarea>
							</div>
</div>


<div class="form-group">
					<label for="default" class="col-sm-2 control-label">Closed Contact Person</label>
							<div class="col-sm-10">
								<textarea rows="3" cols="30" type="text" name="cont_person" class="form-control" id="cont_person"  autocomplete="off"></textarea>
							</div>
</div>



<div class="form-group">
<label for="default" class="col-sm-2 control-label">Vaccinated</label>
<div class="col-sm-10">
<input type="radio" name="vaccinated" value="Yes" required="required" checked=""> Yes <input type="radio" name="vaccinated" value="No" required="required"> No 
</div>
</div>


<!--
<div class="form-group">
<label for="default" class="col-sm-2 control-label">Place Visited</label>
<div class="col-sm-10">
<input type="text" name="placevisit" class="form-control" id="placevisit" required="required" autocomplete="off">
<button type="button" name="aadd" id="aadd" class="btn btn-success" >Add More</button>
</div>
</div>													


<div class="form-group">
<label for="default" class="col-sm-2 control-label">Closed Contact</label>
<div class="col-sm-10" id="dynamic_field">
<input type="text" name="cpname" class="form-control" id="cpname" required="required" autocomplete="off">
<input type="text" name="cplname" class="form-control" id="cplname" required="required" autocomplete="off">
<input type="text" name="contactnum" class="form-control" id="contactnum" required="required" autocomplete="off">
<button type="button" name="add" id="add" class="btn btn-success" >Add More</button>
</div>
</div>
-->



<!--	
			<div class="form-group" name="add_name" id="add_name">
						<h2 align="center"><a href="http://www.webslesson.info/2016/02/dynamically-add-remove-input-fields-in-php-with-jquery-ajax.html"></a></h2><br />
							<label for="default" class="col-sm-2 control-label">Place Visited</label>
						<table class="table table-bordered" id="dynamic_field">
							<tr>
							
								<td     ><input type="text" name="placevisit[]" placeholder="Place Visited" class="form-control name_list" /></td>
								<td     ><button type="button" name="add" id="add" class="btn btn-success">Add More</button></td>
							</tr>
						</table>

			</div>
	


<div class="form-group">
	<label for="default" class="col-sm-2 control-label">Place Visited</label>
		<div class="col-sm-10" id="new1">
		<input type="text" name="placevisited[]" class="form-control" id="placevisited" required="required" autocomplete="off" placeholder="Place Visited">
		<button type="button" name="add1" id="add1" class="btn btn-success" >Add More</button>
		</br>
</div>
</div>	



		
<div class="form-group">
	<label for="default" class="col-sm-2 control-label">Closed Contact</label>
		<div class="col-sm-10" id="new">
		<input type="text" name="fname[]" class="form-control" id="fname" required="required" autocomplete="off" placeholder="Full Name">
		<input type="text" name="adress[]" class="form-control" id="adress" required="required" autocomplete="off" placeholder="Address">
		<input type="text" name="contnum[]" class="form-control" id="contnum" required="required" autocomplete="off" placeholder="Contact Number">
		<input type="text" name="relation[]" class="form-control" id="relation" required="required" autocomplete="off" placeholder="Relationship">
		<button type="button" name="add" id="add" class="btn btn-success" >Add More</button>
		</br>
</div>
</div>										
			-->					
    <script type="text/javascript">
        function ShowHideDiv() {
            var ddlPassport = document.getElementById("ddlPassport");
            var dvPassport = document.getElementById("dvPassport");
            dvPassport.style.display = ddlPassport.value == "Positive" ? "block" : "none";
        }
    </script>													
													
													


					<div class="form-group">
					<label for="default" class="col-sm-2 control-label">Status</label>
					<div class="col-sm-10">
					<select name="status" class="form-control" required="required" autocomplete="off">
					<option value="">Status</option>                                          
					<option value="PUI">PUI</option>
					<option value="PUM">PUM</option>
					</select>
					</div>
					</div>


                                                    <div class="form-group">
    <div id="dvPassport" style="display: none">
					<label for="default" class="col-sm-2 control-label">Covid-19 Variant</label>
					<div class="col-sm-10">
					<select name="variant" class="form-control" autocomplete="off">
					<option value="">Select Variant</option>                                          
					<option value="Alpha">Alpha</option>
					<option value="Beta">Beta</option>
					<option value="Gamma">Gamma</option>
					<option value="Delta">Delta</option>
					</select>
					</div>
    </div>
   
                                                    </div>

   
                                                    <div class="form-group">
                                                        <div class="col-sm-offset-2 col-sm-10">
                                                            <button type="submit" name="submit" class="btn btn-primary">      Add to Record</button>
                                                        </div>
                                                    </div>
                                                </form>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-12 -->
                                </div>
                    </div>
                </div>
                <!-- /.content-container -->
            </div>
            <!-- /.content-wrapper -->
        </div>

        <!-- /.main-wrapper -->
        <script src="js/jquery/jquery-2.2.4.min.js"></script>
        <script src="js/bootstrap/bootstrap.min.js"></script>
        <script src="js/pace/pace.min.js"></script>
        <script src="js/lobipanel/lobipanel.min.js"></script>
        <script src="js/iscroll/iscroll.js"></script>
        <script src="js/prism/prism.js"></script>
        <script src="js/select2/select2.min.js"></script>
        <script src="js/main.js"></script>
		<script type="text/javascript" src="js/custom.js"></script>
		<script src="http:ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	
        <script>
            $(function($) {
                $(".js-states").select2();
                $(".js-states-limit").select2({
                    maximumSelectionLength: 2
                });
                $(".js-states-hide").select2({
                    minimumResultsForSearch: Infinity
                });
            });
        </script>
		
	<!--		
		<script>
var survey_options = document.getElementById('survey_options');
var add_more_fields = document.getElementById('add_more_fields');
var remove_fields = document.getElementById('remove_fields');


add_more_fields.onclick = function(){
	var newField = document.createElement('input');
	newField.setAttribute('type','text');
	newField.setAttribute('name','survey_options[]');
	newField.setAttribute('class','survey_options');
	newField.setAttribute('siz','50');
	newField.setAttribute('placeholder','Another Field');
	survey_options.appendChild(newField);
}

remove_fields.onclick = function(){
	var input_tags = survey_options.getElementsByTagName('input';
	if(input_tags.length > 2){
		survey_options.removeChild(input_tags[(input_tags.length)-1]);
	}
}
	

 </script>
-->	
<!--
<script>
$(document).ready(function(){
	var i=1;
	$('#add').click(function(){
		i++;
		$('#new').append('<div id="row'+i+'"> <input type="text" name="fname[]" id="fname" class="form-control" required="required" autocomplete="off" placeholder="Full Name"><input type="text" name="adress[]" id="adress" class="form-control"  required="required" autocomplete="off" placeholder="Address"><input type="text" name="contnum[]" id="contnum" class="form-control" required="required" autocomplete="off" placeholder="Contact Number"><input type="text" name="relation[]" class="form-control" id="relation" autocomplete="off" placeholder="Relationship"> <button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></div>');
	});
	
	$(document).on('click', '.btn_remove', function(){
		var button_id = $(this).attr("id"); 
		$('#row'+button_id+'').remove();
	});
});
</script>


<script>
$(document).ready(function(){
	var i=1;
	$('#add1').click(function(){
		i++;
		$('#new1').append('<div id="row'+i+'"> <input type="text" name="placevisited[]" id="placevisited" class="form-control" required="required" autocomplete="off" placeholder="Place visited"><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove1">X</button></div>');
	});
	
	$(document).on('click', '.btn_remove1', function(){
		var button_id = $(this).attr("id"); 
		$('#row'+button_id+'').remove();
	});
});
</script>
-->		
    </body>
</html>
<?PHP } ?>
