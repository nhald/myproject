<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{

?>
	<head>
	
<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    	<meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Admin Manage</title>
        <link rel="stylesheet" href="css/bootstrap.min.css" media="screen" >
        <link rel="stylesheet" href="css/font-awesome.min.css" media="screen" >
        <link rel="stylesheet" href="css/animate-css/animate.min.css" media="screen" >
        <link rel="stylesheet" href="css/lobipanel/lobipanel.min.css" media="screen" >
        <link rel="stylesheet" href="css/prism/prism.css" media="screen" > <!-- USED FOR DEMO HELP - YOU CAN REMOVE IT -->
        <link rel="stylesheet" type="text/css" href="js/DataTables/datatables.min1.css"/>
        <link rel="stylesheet" href="css/main1.css" media="screen" >
        <script src="js/modernizr/modernizr.min.js"></script>	
	
		<style>	
		.table {
			width: 100%;
			margin-bottom: 20px;
			margin-top: 10px;

		}	
		
		.table-striped tbody > tr:nth-child(odd) > td,
		.table-striped tbody > tr:nth-child(odd) > th {
			background-color: #f9f9f9;
		}
		
		@media print{
			#print {
				display:none;
			}
		}
		@media print {
			#PrintButton {
				display: none;
			}
		}
		
		@page {
			size: auto;   /* auto is the initial value */

		}
	</style>
	</head>
<body>
<?php if($msg){?>
<?php } 
else if($error){?>
    <div class="alert alert-danger left-icon-alert" role="alert">
                                            <strong>Oh snap!</strong> <?php echo htmlentities($error); ?>
                                        </div>
                                        <?php } ?>
                                            <div class="panel-body p-20">
                            <div class="row page-title-div">
                                <div class="col-md-6">
																<center><img src="tabacocity.png" width="100" height="100"></center>
                                    <h2 class="title">Reports of Covid-19 Records in Tabaco City Albay</h2>
                                </div>
                                </div>								
                                <div class="col-md-6">                                
                                <!-- /.col-md-6 text-right -->
                            </div>
                                             <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th>Patient No.</th>
                                                            <th>First Name</th>                                                    
                                                            <th>Middle Name</th>
                                                            <th>Last Name</th>
                                                            <th>Resident</th>																
                                                            <th>Covid-19 Variant</th>
                                                            <th>Status</th>
                                                        </tr>
                                                    </thead>

                                                    <tbody>
<?php 
$status='Positive';
$sql = "SELECT tblRecord.RecordFname,tblRecord.RecordMname,tblRecord.RecordLname,tblrecord.Variant,tblrecord.RecordId,tblrecord.Status,tblrecord.BrgName from tblrecord where tblrecord.Status=:status";
$query = $dbh->prepare($sql);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{   ?>
<tr>
 <td><?php echo htmlentities($cnt);?></td>
                                                            <td><?php echo htmlentities($result->RecordFname);?></td>
                                                            <td><?php echo htmlentities($result->RecordMname);?></td>  
                                                            <td><?php echo htmlentities($result->RecordLname);?></td>
                                                            <td><?php echo htmlentities($result->BrgName);?></td>															
                                                            <td><?php echo htmlentities($result->Variant);?></td>													

                                                                       <td><?php $stats=$result->Status;
if($stats=='PUI'){
                                             ?>
                                                <span style="color: orange">PUI</span>
                                                 <?php } if($stats=='PUM')  { ?>
                                                <span style="color: brown">PUM</span>
                                                 <?php } if($stats=='Positive')  { ?>
												<span style="color: red">Positive</span>
												 <?php } if($stats=='Vaccinated')  { ?>
												<span style="color: red">Vaccinated</span>
												 <?php } if($stats=='Recovered')  { ?>
												<span style="color: red">Recovered</span>
												 <?php } if($stats=='Death')  { ?>
												<span style="color: red">Death</span>
 <?php } ?>


                                             </td>

</tr>
<?php $cnt=$cnt+1;}} ?>
                                                       
                                                    
                                                    </tbody>
                                                </table>

                                         
                                                <!-- /.col-md-12 -->
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-6 -->

                                                               
                                                </div>
                                                <!-- /.col-md-12 -->
                                            </div>
                                        </div>
                                        <!-- /.panel -->
                                    </div>
                                    <!-- /.col-md-6 -->

                                </div>
                                <!-- /.row -->

                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <!-- /.section -->

                    </div>
                    <!-- /.main-page -->

                    

                </div>
                <!-- /.content-container -->
            </div>
            <!-- /.content-wrapper -->

        </div>
<center><button id="PrintButton" onclick="PrintPage()">Print</button></center>


</body>
<script type="text/javascript">
	function PrintPage() {
		window.print();
	}
	document.loaded = function(){
		
	}
	window.addEventListener('DOMContentLoaded', (event) => {
   		PrintPage()
		setTimeout(function(){ window.close() },750)
	});
</script>
</html>
<?php } ?>