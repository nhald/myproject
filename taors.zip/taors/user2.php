<?php
session_start();
error_reporting(0);
include('includes/config.php');
if($_SESSION['alogin']!=''){
$_SESSION['alogin']='';
}
if(isset($_POST['login1']))
{
$uname=$_POST['username'];
$password=md5($_POST['password']);
$sql ="SELECT uname,password FROM users WHERE uname=:uname and password=:password";
$query= $dbh -> prepare($sql);
$query-> bindParam(':uname', $uname, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
$_SESSION['alogin']=$_POST['username'];
echo "<script type='text/javascript'> document.location = 'dashboard1.php'; </script>";
} else{

    echo "<script>alert('Invalid Details');</script>";

}

}

?>
<!doctype html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
	
    <title>TAORS-ISP</title>
	<link rel="icon" href="https://www.iconpacks.net/icons/2/free-shopping-bag-icon-2041-thumb.png">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css">

    <!-- Bootstrap javascript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
  </head>



  <body>
    <nav class="navbar navbar-expand-md navbar-light p-3 px-md-4 mb-3 bg-body border-bottom shadow-sm">
	  <div class="container-fluid">
		<a class="navbar-brand">
		     <H4>TAORS-ISP</H4>
		</a>
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		  <span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarSupportedContent">
		  <ul class="navbar-nav ms-auto mb-2 mb-lg-0 d-flex">
			<li class="nav-item px-2">
			    <a class="btn btn-outline-primary" href="index.php">Admin</a>
			</li>
		  </ul>
		</div>
	  </div>
    </nav>




    <div class="container-fluid">
        <div class="mx-auto pt-5 pb-5" style="width: 400px;">
            <div class="card">
                <div class="card-body">
                    <form class="form-horizontal" method="POST">
                        <h3 class="mb-3 font-weight-normal text-center pb-4">User Login</h3>
						                        <h6 class="mb-3 font-weight-normal text-center pb-4">Successfully Registered!</h6>

						<div class="mb-3">
							<label for="inputEmail3" class="form-label">Email</label>
						    <input type="text" class="form-control" id="inputEmail3" name="username">
						</div>
						<div class="mb-3">
							<label for="inputPassword3" class="form-label">Password</label>
							<input type="password" class="form-control"  id="inputPassword3" name="password">
                            <?php 
                            if (!empty($error)) {
                                echo "<p style='color:red;'>$error</p>"; 
                            }
                            ?>
						</div>
						
						<div class="mb-3 d-grid">
							<button type="submit" name="login1" class="btn btn-primary">Login</button>
						</div>
					
<a class="btn btn-outline-primary" href="register.php">Register</a>
                    </form>
                </div>
            </div>
        </div>
    </div>



<footer class="container pt-4 my-3 border-top">
    <div class="row">
        <div class="col-12 text-center">
        <small class="d-block mb-3 text-muted">&copy; TAORS-ISP 2021</small>
        </div>
    </div>
</footer>

</body>
</html>
17–2021</small>
        </div>
    </div>
</footer>

</body>
</html>