-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2021 at 06:24 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `taors`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2021-06-15 13:05:39'),
(3, 'admin1', '21232f297a57a5a743894a0e4a801fc3', '2021-06-15 13:05:39');

-- --------------------------------------------------------

--
-- Table structure for table `placevisited`
--

CREATE TABLE `placevisited` (
  `PlaceId` int(11) NOT NULL,
  `PlaceVisit` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `placevisited`
--

INSERT INTO `placevisited` (`PlaceId`, `PlaceVisit`) VALUES
(157, 'tambo'),
(158, 'basag'),
(159, 'bali'),
(160, 'amtic'),
(161, 'gg'),
(162, 'werwer'),
(163, 'werwer'),
(164, 'hjghj'),
(165, 'u7u67u67u'),
(166, 'ghjgh');

-- --------------------------------------------------------

--
-- Table structure for table `tblclasses`
--

CREATE TABLE `tblclasses` (
  `id` int(11) NOT NULL,
  `BaranggayName` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblclasses`
--

INSERT INTO `tblclasses` (`id`, `BaranggayName`) VALUES
(1, 'Agnas (San Miguel Island)'),
(2, 'Bacolod'),
(3, 'Bangkilingan'),
(4, 'Bantayan'),
(5, 'Baranghawon'),
(6, 'Basagan'),
(7, 'Basud (Poblacion)'),
(8, 'Bogñabong'),
(9, 'Bombon (Poblacion)'),
(10, 'Bonot'),
(11, 'San Isidro (Boring)'),
(12, 'Buang'),
(13, 'Buhian'),
(14, 'Cabagñan'),
(15, 'Cobo'),
(16, 'Comon'),
(17, 'Cormidal'),
(18, 'Divino Rostro (Poblacion)'),
(19, 'Fatima'),
(20, 'Guinobat'),
(21, 'Hacienda (San Miguel Island)'),
(22, 'Magapo'),
(23, 'Mariroc'),
(24, 'Matagbac'),
(25, 'Oras'),
(26, 'Oson'),
(27, 'Panal'),
(28, 'Pawa'),
(29, 'Pinagbobong'),
(30, 'Quinale Cabasan (Poblacion)'),
(31, 'Quinastillojan'),
(32, 'Rawis (San Miguel Island)'),
(33, 'Sagurong (San Miguel Island)'),
(34, 'Salvacion'),
(35, 'San Antonio'),
(36, 'San Carlos'),
(37, 'San Juan (Poblacion)'),
(38, 'San Lorenzo'),
(39, 'San Ramon'),
(40, 'San Roque'),
(41, 'San Vicente'),
(42, 'Santo Cristo (Poblacion)'),
(43, 'Sua-Igot'),
(44, 'Tabiguian'),
(45, 'Tagas'),
(46, 'Tayhi (Poblacion)'),
(47, 'Visita (San Miguel Island)');

-- --------------------------------------------------------

--
-- Table structure for table `tblrecord`
--

CREATE TABLE `tblrecord` (
  `RecordId` int(11) NOT NULL,
  `RecordFname` varchar(100) NOT NULL,
  `RecordMname` varchar(100) NOT NULL,
  `RecordLname` varchar(100) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `BrgName` varchar(100) NOT NULL,
  `DOB` varchar(150) NOT NULL,
  `DOQ` date NOT NULL,
  `RegDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Status` varchar(50) NOT NULL,
  `ContactNum` varchar(11) NOT NULL,
  `Contact_Person` varchar(1000) NOT NULL,
  `Place_Visited` varchar(5000) NOT NULL,
  `Vaccinated` varchar(50) NOT NULL,
  `Variant` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblrecord`
--

INSERT INTO `tblrecord` (`RecordId`, `RecordFname`, `RecordMname`, `RecordLname`, `Gender`, `BrgName`, `DOB`, `DOQ`, `RegDate`, `UpdationDate`, `Status`, `ContactNum`, `Contact_Person`, `Place_Visited`, `Vaccinated`, `Variant`) VALUES
(177, 'gg', 'gg', 'gg', 'Male', 'Bacolod', '2021-06-13', '2021-01-13', '2021-06-13 14:36:24', '2021-07-27 01:54:17', 'PUM', 'gg', '', '', 'Yes', ''),
(178, 'jojo', 'jojo', 'jojo', 'Male', 'Fatima', '2021-06-09', '2021-06-10', '2021-06-15 17:39:34', '2021-07-26 19:50:16', 'Death', 'ewrwer', 'Mikel aba, 0943423439, Tambo Ligao City,\r\nJUN Aba, 09343432423, Cobo, Tabaco City', 'Tabaco City, ligao City, Albay, Santa Rosa', 'No', ''),
(179, 'ewr', 'werwer', 'werwer', 'Male', 'Bangkilingan', '2021-06-09', '2021-06-10', '2021-06-15 17:53:24', '2021-07-30 23:04:44', 'Recovered', '09456785746', 'olololololololl', 'lololololo', 'No', ''),
(180, 'fghfg', 'hfgh', 'hfghfgh', 'Male', 'Bacolod', '2021-06-16', '2021-06-15', '2021-06-15 20:20:31', '2021-07-27 08:43:30', 'Death', 'gfhfg', 'hjh\r\njhjh\r\njh\r\njh\r\nj\r\nh\r\njh\r\nj\r\nh\r\njhjhjhj\r\nh\r\njh\r\nj', 'opopopo\r\nopopopo\r\npopopopo\r\npopopopop', 'No', ''),
(181, 'tyut', 'yutyu', 'tyutyu', 'Male', 'Bangkilingan', '2021-06-15', '2021-06-15', '2021-06-15 20:45:24', '2021-07-30 23:06:25', 'Positive', '09127681276', 'jhgjhghjghjghj\r\ndfhdfhfdh fdhdfhdfhd fh       dfhdfhdfh\r\ndfhdfhdfhfdh', 'ghjghj         dfghdfhdfhfdhf\r\ndfhgdfhdf\r\ndfhdfhdfhdf\r\nhdfh\r\ndfhg\r\ndfh\r\ndfhd\r\nfhdfhdfhdfh', 'No', ''),
(182, 'yyu', 'iyui', 'iyuiyuii', 'Male', 'Divino Rostro (Poblacion)', '2021-06-15', '2021-06-15', '2021-06-15 20:47:23', '2021-07-19 21:01:25', 'Positive', 'yuiyuiyui', 'dfgdfgdfgdfgdfg', 'gdfgdfgdfg', 'Yes', ''),
(183, 'fhfgh', 'gfhfg', 'hfghgfh', 'Male', 'Agnas (San Miguel Island)', '2021-06-02', '2021-06-04', '2021-06-16 14:36:24', '2021-07-27 08:44:06', 'Death', 'gfhfgh', 'fghfghfghfgh\r\nfghfghfghfghfg\r\ngfhgfhgfhfghfg\r\nfghfghfghgfhfgh\r\nfghfghfghfghfgh', 'fghfghgfh\r\nfghfghfgh\r\nfghfghfghfgh\r\nfghfghfghfgh\r\nfghfghfghfgh', 'Yes', ''),
(184, 'hony', 'hony', 'hony', 'Female', 'Fatima', '2021-06-16', '2021-06-17', '2021-06-16 19:28:49', '2021-07-20 02:05:23', 'Positive', '09456875474', 'toytoy, 0913445347, Cobo, Tabaco City\r\nRowel Cabrera, 0945345434, Pawa, Tabaco City\r\nKoy koy, 0934234343, Pawa, Tabaco City', 'Cobo, Tabaco City\r\nPawa, Tabaco City\r\nMalilipot, Albay', 'No', 'Delta'),
(185, 'michael', 'bro', 'loren', 'Male', 'Fatima', '2021-06-16', '2021-06-16', '2021-06-16 22:57:31', '2021-07-20 02:05:37', 'Positive', '0978787867', 'sabdkjhabsdkjhbasd\r\nasdjhaksjdhkasjdhklasd\r\nasdlkaskldjhaksjdhkalsj', 'sahgdakshd\r\nasdahsgdjahsgd\r\nasjdhkajshdkjashd', 'Yes', 'Delta'),
(186, 'hjghjghj', 'ghjghj', 'ghjghjghj', 'Male', 'Cobo', '2021-06-18', '2021-06-18', '2021-06-18 09:02:47', '2021-07-27 02:12:25', 'Death', '09694560456', 'dfgd\r\nfgdfg\r\ndfg\r\ndf\r\ngdf\r\ng', 'oifogjdfjgmg \r\ndfgdfgdfgdfg\r\ndfgdfgdfgdfg', 'Yes', ''),
(187, 'qqqqq', 'qqqq', 'qqqqq', 'Male', 'Comon', '2021-07-16', '2021-07-16', '2021-07-16 23:35:14', '2021-07-16 23:45:04', 'Positive', '54353453454', 'sdfsdfsdfdfdf', 'sdfsdfsdfsdf', 'Yes', 'Alpha'),
(188, 'gfhfghfgh', 'fghfghfgh', 'tryrtytry', 'Male', 'Agnas (San Miguel Island)', '2021-07-16', '2021-07-16', '2021-07-16 23:40:33', '2021-07-20 02:04:38', 'Positive', '65765756765', 'gjghj', 'hjghjh', 'Yes', 'Gamma'),
(189, 'gg', 'gg', 'gg', 'Male', 'Bacolod', '2021-06-13', '2021-06-13', '2021-06-13 14:36:24', '2021-07-20 02:03:16', 'Death', 'gg', 'dfgdfgdfgdfgd\r\nfgdfgdfgdfgdfg\r\ndfgdfgdfgdfg', 'rgdfgdf\r\ngdfgdfgdf\r\ngdfgdfgdfg', 'Yes', ''),
(190, 'jojo', 'jojo', 'jojo', 'Male', 'Fatima', '2021-06-09', '2021-06-10', '2021-06-15 17:39:34', '2021-06-22 21:14:22', 'Positive', 'ewrwer', 'Mikel aba, 0943423439, Tambo Ligao City,\r\nJUN Aba, 09343432423, Cobo, Tabaco City', 'Tabaco City, ligao City, Albay, Santa Rosa', 'No', ''),
(191, 'ewr', 'werwer', 'werwer', 'Male', 'Bangkilingan', '2021-06-09', '2021-06-10', '2021-06-15 17:53:24', '2021-06-25 07:27:32', 'Positive', 'ewrwer', 'olololololololl', 'lololololo', 'No', ''),
(192, 'fghfg', 'hfgh', 'hfghfgh', 'Male', 'Bacolod', '2021-06-16', '2021-06-15', '2021-06-15 20:20:31', '2021-07-20 02:04:45', 'Positive', 'gfhfg', 'hjh\r\njhjh\r\njh\r\njh\r\nj\r\nh\r\njh\r\nj\r\nh\r\njhjhjhj\r\nh\r\njh\r\nj', 'opopopo\r\nopopopo\r\npopopopo\r\npopopopop', 'No', 'Delta'),
(193, 'tyut', 'yutyu', 'tyutyu', 'Male', 'Bangkilingan', '2021-06-15', '2021-06-15', '2021-06-15 20:45:24', '2021-07-26 00:48:56', 'Recovered', 'tyuty', '', '', 'No', ''),
(194, 'yyu', 'iyui', 'iyuiyuii', 'Male', 'Fatima', '2021-06-15', '2021-06-15', '2021-06-15 20:47:23', '2021-07-20 02:05:48', 'Positive', 'yuiyuiyui', 'dfgdfgdfgdfgdfg', 'gdfgdfgdfg', 'Yes', ''),
(195, 'fhfgh', 'gfhfg', 'hfghgfh', 'Male', 'Fatima', '2021-06-02', '2021-06-04', '2021-06-16 14:36:24', '2021-07-20 02:06:11', 'Positive', 'gfhfgh', 'fghfghfghfgh\r\nfghfghfghfghfg\r\ngfhgfhgfhfghfg\r\nfghfghfghgfhfgh\r\nfghfghfghfghfgh', 'fghfghgfh\r\nfghfghfgh\r\nfghfghfghfgh\r\nfghfghfghfgh\r\nfghfghfghfgh', 'Yes', 'Gamma'),
(196, 'hony', 'hony', 'hony', 'Female', 'Fatima', '2021-06-16', '2021-06-17', '2021-06-16 19:28:49', '2021-07-20 02:06:25', 'Positive', '09456875474', 'toytoy, 0913445347, Cobo, Tabaco City\r\nRowel Cabrera, 0945345434, Pawa, Tabaco City\r\nKoy koy, 0934234343, Pawa, Tabaco City', 'Cobo, Tabaco City\r\nPawa, Tabaco City\r\nMalilipot, Albay', 'No', 'Delta'),
(197, 'michael', 'bro', 'loren', 'Male', 'Fatima', '2021-06-16', '2021-06-16', '2021-06-16 22:57:31', '2021-07-20 02:06:40', 'Positive', '0978787867', 'sabdkjhabsdkjhbasd\r\nasdjhaksjdhkasjdhklasd\r\nasdlkaskldjhaksjdhkalsj', 'sahgdakshd\r\nasdahsgdjahsgd\r\nasjdhkajshdkjashd', 'Yes', 'Delta'),
(198, 'hjghjghj', 'ghjghj', 'ghjghjghj', 'Male', 'Cobo', '2021-06-18', '2021-06-18', '2021-06-18 09:02:47', '2021-06-22 21:14:54', 'Positive', '09694560456', 'dfgd\r\nfgdfg\r\ndfg\r\ndf\r\ngdf\r\ng', 'oifogjdfjgmg \r\ndfgdfgdfgdfg\r\ndfgdfgdfgdfg', 'Yes', ''),
(199, 'qqqqq', 'qqqq', 'qqqqq', 'Male', 'Comon', '2021-07-16', '2021-07-16', '2021-07-16 23:35:14', '2021-07-16 23:45:04', 'Positive', '54353453454', 'sdfsdfsdfdfdf', 'sdfsdfsdfsdf', 'Yes', 'Alpha'),
(200, 'gfhfghfgh', 'fghfghfgh', 'tryrtytry', 'Male', 'Agnas (San Miguel Island)', '2021-07-16', '2021-07-16', '2021-07-16 23:40:33', '2021-07-20 02:04:58', 'Positive', '65765756765', 'gjghj', 'hjghjh', 'Yes', ''),
(201, 'hhjkhjk', 'hjkhjkhjk', 'jkhjkhjkhjk', 'Male', 'Divino Rostro (Poblacion)', '2021-07-18', '2021-07-18', '2021-07-18 07:26:58', NULL, 'Positive', '7867867867', 'uyiyuiyuiyuiyu\r\nyuiyuiyui\r\nyuiuiyuiyui', 'iyuiyuiyuiyuii\r\nuyoyuoyuoy', 'Yes', 'Alpha'),
(202, 'dfhdfs', 'hdshdfhd', 'fhdsfhdfhsdfh', 'Male', 'Cormidal', '2021-07-22', '2021-07-22', '2021-07-22 20:42:49', '2021-07-22 22:29:30', 'Positive', '6456456456', 'terterter', 'ertaerter', 'Yes', 'Gamma'),
(203, 'dfgdfg', 'dsfgdfg', 'dfsgsdfgsdfg', 'Male', 'Fatima', '2021-07-22', '2021-07-22', '2021-07-22 20:43:37', '2021-07-23 19:04:24', 'Positive', '56456456', 'yrtyerty', 'rtyrtyrt', 'Yes', 'Alpha'),
(204, 'yrty', 'tryrtyrty', 'rtyrty', 'Male', 'Cabagñan', '2021-07-22', '2021-07-22', '2021-07-22 20:44:25', '2021-07-26 19:19:35', 'Death', 'rt886786786', 'yeryrtyrt', 'ygetyer', 'Yes', ''),
(205, 'AWIT', 'werwerwer', 'werwe', 'Male', 'Comon', '2021-07-22', '2021-07-22', '2021-07-22 20:45:23', '2021-07-30 16:12:28', 'PUI', '09465678678', 'ergergerge', 'rertertg', 'Yes', ''),
(206, 'ertert', 'erterter', 'ertert', 'Male', 'Cormidal', '2021-07-22', '2021-07-22', '2021-07-22 20:46:23', '2021-07-26 20:13:14', 'Positive', '5464564565', 'tertertert', 'reterter', 'Yes', 'Delta'),
(207, 'htrrthrth', 'rthrt', 'hrthrthrt', 'Male', 'Hacienda (San Miguel Island)', '2021-07-22', '2021-07-22', '2021-07-22 20:47:18', '2021-07-26 20:31:11', 'Positive', 'hrthrth', 'yeryery', 'eryer', 'Yes', 'Delta'),
(208, 'rege', 'rgerg', 'ergerg', 'Male', 'Guinobat', '2021-07-22', '2021-07-22', '2021-07-22 20:49:05', '2021-07-30 16:18:23', 'Non-Positive', '09124325435', 'gergerg', 'ger', 'Yes', ''),
(209, 'rtyerytrytr', 'yrtyrty', 'rtyrtytry', 'Male', 'Comon', '2021-07-22', '2021-07-22', '2021-07-22 20:50:56', '2021-07-29 17:05:20', 'Non-Positive', '5464564564', 'tuturturt', 'rturtur', 'Yes', ''),
(210, 'rth', 'rthrthrth', 'rthrthr', 'Male', 'Comon', '2021-07-22', '2021-07-22', '2021-07-22 21:46:15', NULL, 'PUI', 'rtrthrth', 'try', 'tr', 'Yes', ''),
(211, 'rth', 'rthrthrth', 'rthrthr', 'Male', 'Comon', '2021-07-22', '2021-07-22', '2021-07-22 21:48:04', NULL, 'PUI', 'rtrthrth', 'try', 'tr', 'Yes', ''),
(212, 'fghfg', 'hfghfg', 'hfghf', 'Male', 'Comon', '2021-07-22', '2021-07-22', '2021-07-22 21:48:21', NULL, 'PUI', 'fghfghfgh', 'ytjtyjtyj', 'yjtyjtyj', 'Yes', ''),
(213, 'fghfg', 'hfghfg', 'hfghf', 'Male', 'Comon', '2021-07-22', '2021-07-22', '2021-07-22 21:49:17', NULL, 'PUI', 'fghfghfgh', 'ytjtyjtyj', 'yjtyjtyj', 'Yes', ''),
(214, 'fghfg', 'hfghfg', 'hfghf', 'Male', 'Comon', '2021-07-22', '2021-07-22', '2021-07-22 21:49:33', NULL, 'PUI', 'fghfghfgh', 'ytjtyjtyj', 'yjtyjtyj', 'Yes', ''),
(215, 'fghfg', 'hfghfg', 'hfghf', 'Male', 'Comon', '2021-07-22', '2021-07-22', '2021-07-22 21:51:24', '2021-07-27 08:42:05', 'Positive', 'fghfghfgh', 'ytjtyjtyj', 'yjtyjtyj', 'Yes', ''),
(216, 'reger', 'gergerg', 'ergerge', 'Male', 'Bacolod', '2021-07-22', '2021-07-22', '2021-07-22 21:52:26', NULL, 'PUM', 'ergerg', 'rthrthrth', 'thrthrth', 'Yes', ''),
(217, 'ergerg', 'ergergeg', 'ergerge', 'Male', 'Divino Rostro (Poblacion)', '2021-07-22', '2021-07-22', '2021-07-22 21:52:56', NULL, 'PUM', 'erger', 'tgrtgrtgrt', 'tgrtgr', 'Yes', ''),
(218, '54y45y4', 'rgrg', 'ergergerg', 'Male', 'Cormidal', '2021-07-22', '2021-07-22', '2021-07-22 21:54:33', NULL, 'PUI', 'ergergreger', 'trhrthrthrth', 'hrthrthrh', 'Yes', ''),
(219, 'trhrth', 'rthrthr', 'thrthrth', 'Male', 'Cormidal', '2021-07-22', '2021-07-22', '2021-07-22 21:54:50', NULL, 'PUI', 'rthrthrt', 'tyjtyjtyj', 'yyjtyjtyj', 'Yes', ''),
(220, 'rthrth', 'hrthrthrth', 'rthrth', 'Male', 'Pinagbobong', '2021-07-22', '2021-07-22', '2021-07-22 21:55:56', NULL, 'PUI', 'hrthrth', 'hrthrthrth', 'rthrt', 'Yes', ''),
(221, 'rthrth', 'hrthrthrth', 'rthrth', 'Male', 'Pinagbobong', '2021-07-22', '2021-07-22', '2021-07-22 21:56:10', NULL, 'PUI', 'hrthrth', 'hrthrthrth', 'rthrt', 'Yes', ''),
(222, 'trhrthh', 'hrthrth', 'rhrthrth', 'Male', 'Fatima', '2021-07-22', '2021-07-22', '2021-07-22 21:56:38', NULL, 'PUI', 'rthrthrth', 'ghjghjghj', 'jghjghjghj', 'Yes', ''),
(223, 'fgdfgdfg', 'dfgdfgdfgd', 'gdfgdfgdfg', 'Male', 'Cabagñan', '2021-07-22', '2021-07-22', '2021-07-22 22:05:11', NULL, 'PUI', 'fdfgdfgdf', 'yukyukyuk', 'yukyukyuk', 'Yes', ''),
(224, 'rgerg', 'egregrg', 'ergerg', 'Male', 'Divino Rostro (Poblacion)', '2021-07-22', '2021-07-22', '2021-07-22 22:27:46', NULL, 'PUI', 'gergergerg', 'hrthrthrthrth', 'rtrtrththrth', 'Yes', ''),
(225, 'fdvdfvdfv', 'dfvdfvdfv', 'dfvdfvdfv', 'Male', 'Fatima', '', '0000-00-00', '2021-07-22 22:28:41', NULL, 'PUI', 'fdvdfvdfv', 'vxcvxvxcvxv', 'vxcvxcvxc', 'Yes', ''),
(226, 'ghjgh', 'jghjghjghj', 'jghjghjghj', 'Male', 'Fatima', '2021-07-22', '2021-07-22', '2021-07-23 00:47:47', NULL, 'PUI', 'hgjghjghjgh', 'hjkhjkhjk', 'khjkghk', 'Yes', ''),
(227, 'yuyuty', 'tyutyu', 'tyutyuty', 'Male', 'Cabagñan', '2021-07-22', '2021-07-22', '2021-07-23 00:48:15', NULL, 'PUI', 'ytutyutyu', 'jtyjtjtyj', 'tyjtyjtyjty', 'Yes', ''),
(228, 'gfhfgh', 'fghfghfg', 'hfghfghfh', 'Male', 'Bantayan', '2021-07-22', '2021-07-22', '2021-07-23 01:14:23', NULL, 'PUI', 'fghfghfghfg', 'hgjghj', 'ghjghjgh', 'Yes', ''),
(229, 'fddf', 'dfdfbd', 'fbdfbdfbfdb', 'Male', 'Agnas (San Miguel Island)', '4444-04-04', '4444-04-04', '2021-07-26 00:19:55', NULL, 'PUI', 'dfbdfbdfbdf', 'dfgdfgdfggdfg', 'fdgdfgdfgfg', 'Yes', ''),
(230, 'gfhfgh', 'fghfghf', 'ghfgh', 'Male', 'Bacolod', '2021-07-26', '2021-07-26', '2021-07-26 20:19:01', NULL, 'PUI', 'fghfghfghfg', 'fghfghfghfgh', 'ghfghfghfghfghfghfgh', 'Yes', ''),
(231, 'dfgdf', 'gdfgdfg', 'dfgdfg', 'Male', 'Divino Rostro (Poblacion)', '2021-07-26', '2021-07-26', '2021-07-26 20:22:41', NULL, 'Death', 'dfgdfgdfg', 'hfghfghfgh', 'hfghfg', 'Yes', ''),
(232, 'fd', 'dfbdfbd', 'dfbdfb', 'Male', 'Comon', '2021-07-26', '2021-07-26', '2021-07-26 20:24:45', NULL, 'PUI', 'dfbdfb', 'dfbdf', 'fddf', 'Yes', ''),
(233, 'cvbcvb', 'cvbcvbcvbc', 'cvbcvb', 'Male', 'Comon', '2021-07-26', '2021-07-26', '2021-07-26 20:25:24', '2021-07-26 20:30:51', 'Positive', 'cvbcvb', 'bcvbcvbc', 'cvbcv', 'Yes', 'Gamma'),
(234, 'cvncv', 'nvbnvbn', 'vbnvbn', 'Male', 'Bacolod', '2021-07-26', '2021-07-26', '2021-07-26 20:25:46', NULL, 'PUI', 'bvnvbnvb', 'vncvncvn', 'gncvnc', 'Yes', ''),
(235, 'fghfgh', 'fghfgh', 'fghfgh', 'Male', 'Bangkilingan', '2021-07-26', '2021-07-26', '2021-07-27 02:02:36', NULL, 'PUI', 'fghfgh', 'ghjghjghj', 'ghjghjghjg', 'No', ''),
(236, 'dfgdf', 'gdfgdfg', 'dfgdfgdfg', 'Male', 'Guinobat', '2021-07-26', '2021-07-26', '2021-07-27 02:04:42', NULL, 'PUI', 'dfgdfgdfgdf', 'hjghjhgj', 'hghjghjg', 'No', ''),
(237, ';p[', 'o9', 'u8', 'Male', 'Bangkilingan', '2021-06-28', '2021-07-05', '2021-07-27 08:38:24', NULL, 'PUI', '09101234567', 't566yjjki', 'ooi', 'Yes', ''),
(238, ';p', 'ii99op', 'juuk', 'Male', 'Divino Rostro (Poblacion)', '2021-06-27', '2021-07-16', '2021-07-27 08:40:20', NULL, 'PUM', '09456789076', 'kujujh', '88unm,', 'Yes', ''),
(239, 'rtertrtyrtyrt', 'tryrty', 'tyrty', 'Male', 'Agnas (San Miguel Island)', '2021-07-29', '2021-07-29', '2021-07-29 17:07:31', NULL, 'PUI', 'tryrtyrtyrt', 'retertertertert', 'ertertertert', 'Yes', ''),
(240, 'dole', 'dole', 'dole', 'Male', 'Comon', '2021-07-30', '2021-07-30', '2021-07-30 23:01:37', NULL, 'PUI', '09123654567', 'mike lee\r\ntayson boo\r\neric montes', 'cobo, tabaco cit\r\nmalinao albay\r\nbuang. tabaco city', 'Yes', ''),
(241, 'tarzan', 'tarzan', 'tarzan', 'Male', 'Bonot', '2021-07-30', '2021-07-30', '2021-07-30 16:22:30', NULL, 'PUM', '09453234234', 'loui boy\r\nmary rose', 'ligao\r\ntiwi\r\ntabco', 'Yes', '');

-- --------------------------------------------------------

--
-- Table structure for table `tblrecord2`
--

CREATE TABLE `tblrecord2` (
  `RecId` int(11) NOT NULL,
  `Fname` varchar(100) NOT NULL,
  `Contnum` varchar(100) NOT NULL,
  `Adress` varchar(100) NOT NULL,
  `Relationship` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblrecord2`
--

INSERT INTO `tblrecord2` (`RecId`, `Fname`, `Contnum`, `Adress`, `Relationship`) VALUES
(25, 'john', 'pol', '099999999', 'friend'),
(26, 'jil', 'ol', '088888888', 'friend'),
(27, 'ewrwe', 'rwer', 'werwer', 'werwer'),
(28, 'ewrwe', 'rwer', 'werwer', 'werwer'),
(29, 'ghjghj', 'ghj', 'jghj', 'ghjghj'),
(30, '67u67u', '67u67', 'u67u', '67u67u'),
(31, 'jghjg', 'hjgh', 'jghjgh', 'jhjghjhgj');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `UserName1` varchar(100) NOT NULL,
  `Password1` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(1000) NOT NULL,
  `password` varchar(100) NOT NULL,
  `created_at` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `uname`, `email`, `phone`, `password`, `created_at`) VALUES
(40, 'lolo', 'lolo', 'admin3', 'admin@gmail.com', '09534534534', '96e79218965eb72c92a549dd5a330112', '2021-06-25 09:15:28'),
(41, 'iiiiiiii', 'iiiiiiiiiii', 'noy', 'admyyyin@gmail.com', '09534534534', '96e79218965eb72c92a549dd5a330112', '2021-06-25 09:22:58'),
(42, 'rommel', 'john', 'rj', 'mtagdamhhhhhnohoey@gmail.com', '09534534534', '1bbd886460827015e5d605ed44252251', '2021-06-25 13:12:19'),
(43, 'gjfghfg', 'hfghfghfg', 'rjj', 'magdamanoy@gmail.com', '09534534534', '21232f297a57a5a743894a0e4a801fc3', '2021-06-25 13:15:21'),
(44, 'rommel', 'pingo', 'nhoy', 'magdamttanooey@gmail.com', '09534534534', '21232f297a57a5a743894a0e4a801fc3', '2021-06-25 17:54:44'),
(45, 'rtger', 'rtert', 'admin', 'admin@gma11il.com', '09534534534', 'b0baee9d279d34fa1dfd71aadb908c3f', '2021-06-26 03:09:40'),
(46, 'gggggg', 'ggggg', 'admin123', 'magdam21312anohoey@gmail.com', '09534534534', 'e3ceb5881a0a1fdaad01296d7554868d', '2021-06-26 12:30:58'),
(47, 'noy', 'noy', 'noy14', 'jhonald.magdaong@nn.com', '099999999999999', '96e79218965eb72c92a549dd5a330112', '2021-07-30 18:13:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `placevisited`
--
ALTER TABLE `placevisited`
  ADD PRIMARY KEY (`PlaceId`);

--
-- Indexes for table `tblclasses`
--
ALTER TABLE `tblclasses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblrecord`
--
ALTER TABLE `tblrecord`
  ADD PRIMARY KEY (`RecordId`);

--
-- Indexes for table `tblrecord2`
--
ALTER TABLE `tblrecord2`
  ADD PRIMARY KEY (`RecId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `placevisited`
--
ALTER TABLE `placevisited`
  MODIFY `PlaceId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=167;

--
-- AUTO_INCREMENT for table `tblclasses`
--
ALTER TABLE `tblclasses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `tblrecord`
--
ALTER TABLE `tblrecord`
  MODIFY `RecordId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=242;

--
-- AUTO_INCREMENT for table `tblrecord2`
--
ALTER TABLE `tblrecord2`
  MODIFY `RecId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
