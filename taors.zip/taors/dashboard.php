<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])=="")
    {
    header("Location: index.php");
    }
    else{
        ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    	<meta name="viewport" content="width=device-width, initial-scale=1">
        <title>TAORS | Dashboard</title>
        <link rel="stylesheet" href="css/bootstrap.min.css" media="screen" >
        <link rel="stylesheet" href="css/font-awesome.min.css" media="screen" >
        <link rel="stylesheet" href="css/animate-css/animate.min.css" media="screen" >
        <link rel="stylesheet" href="css/lobipanel/lobipanel.min.css" media="screen" >
        <link rel="stylesheet" href="css/toastr/toastr.min.css" media="screen" >
        <link rel="stylesheet" href="css/icheck/skins/line/blue.css" >
        <link rel="stylesheet" href="css/icheck/skins/line/red.css" >
        <link rel="stylesheet" href="css/icheck/skins/line/green.css">
        <link rel="stylesheet" href="css/main.css" media="screen" >
        <script src="js/modernizr/modernizr.min.js"></script>
		<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

    </head>
    <body class="top-navbar-fixed">
        <div class="main-wrapper">
              <?php include('includes/topbar.php');?>
            <div class="content-wrapper">
                <div class="content-container">

                    <?php include('includes/leftbar.php');?>

                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-sm-6">
                                    <h2 class="title">Dashboard</h2>
                     <div class="container-fluid">
                            <!-- /.row -->
                            <div class="row">
                                <div class="col-md-6">
									<a href="add-record.php" class="btn btn-success btn-sm btn-flat" align="right">+ Add Record</a>
                                </div>
                             
                            </div>
                            <!-- /.row -->
                        </div>								
								
								

                                </div>
                                <!-- /.col-sm-6 -->
                            </div>
                            <!-- /.row -->

                        </div>
						
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">


<a class="dashboard-stat bg-primary" href="manage-pui.php">
<?php
$sql1 ="SELECT Status from tblrecord WHERE Status='PUI' ";
$query1 = $dbh -> prepare($sql1);
$query1->execute();
$results1=$query1->fetchAll(PDO::FETCH_OBJ);
$total1=$query1->rowCount();
?>

                                            <span class="number"><?php echo htmlentities($total1);?></span>
                                            <span class="name">Person Under Investigation</span>
                                 
                                        </a>
                                        <!-- /.dashboard-stat -->
                                    </div>
                                    <!-- /.col-lg-3 col-md-3 col-sm-6 col-xs-12 -->

                                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">


<a class="dashboard-stat bg-warning" href="manage-pum.php">																				
<?php
$sql ="SELECT Status from tblrecord WHERE Status='PUM' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total3=$query->rowCount();
?>
                                            <span class="number"><?php echo htmlentities($total3);?></span>
                                            <span class="name">Person Under Monitoring</span>
                                   
                                        </a>
                                        <!-- /.dashboard-stat -->
                                    </div>
                                    <!-- /.col-lg-3 col-md-3 col-sm-6 col-xs-12 -->

                                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">


<a class="dashboard-stat bg-danger" href="manage-pwcovid.php">
<?php
$sql2 ="SELECT Status from tblrecord WHERE Status='Positive'";
$query2 = $dbh -> prepare($sql2);
$query2->execute();
$results2=$query2->fetchAll(PDO::FETCH_OBJ);
$total2=$query2->rowCount();
?>
                                            <span class="number"><?php echo htmlentities($total2);?></span>
                                            <span class="name">Comfirmed Covid-19 Cases</span>
                             
                                        </a>
                                        <!-- /.dashboard-stat -->
                                    </div>
                                    <!-- /.col-lg-3 col-md-3 col-sm-6 col-xs-12 -->

                                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">						
<a class="dashboard-stat bg-light-black" href="manage-pdeath.php">
<?php
$sql3 ="SELECT Status from tblrecord WHERE Status='Death' ";
$query3 = $dbh -> prepare($sql3);
$query3->execute();
$results3=$query3->fetchAll(PDO::FETCH_OBJ);
$total3=$query3->rowCount();
?>

                                            <span class="number"><?php echo htmlentities($total3);?></span>
                                            <span class="name">Total Death</span>
                                 
                                        </a>
                                        <!-- /.dashboard-stat -->
                                    </div>
                                    <!-- /.col-lg-3 col-md-3 col-sm-6 col-xs-12 -->

										
																
                                        <!-- /.dashboard-stat -->
                                    </div>
                                    <!-- /.col-lg-3 col-md-3 col-sm-6 col-xs-12 -->

                                </div>
                                <!-- /.row -->
                        
                            <!-- /.container-fluid -->
				
						
<div class="container-fluid">
<div class="row">            

                                    <!-- /.col-lg-3 col-md-3 col-sm-6 col-xs-12 -->
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">                                    																							
<a class="dashboard-stat bg-success" href="manage-preco.php">	
<?php
$sql5 ="SELECT Status from tblrecord WHERE Status='Recovered' ";
$query5 = $dbh -> prepare($sql5);
$query5->execute();
$results5=$query5->fetchAll(PDO::FETCH_OBJ);
$total5=$query5->rowCount();
?>

                                            <span class="number"><?php echo htmlentities($total5);?></span>
                                            <span class="name">Recovered</span>
																			
                                    
                                        </a>
</div>


<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">                                    																							
<a class="dashboard-stat bg-success" href="manage-nonPositive.php">	
<?php
$sql5 ="SELECT Status from tblrecord WHERE Status='Non-Positive' ";
$query5 = $dbh -> prepare($sql5);
$query5->execute();
$results5=$query5->fetchAll(PDO::FETCH_OBJ);
$total5=$query5->rowCount();
?>

                                            <span class="number"><?php echo htmlentities($total5);?></span>
                                            <span class="name">Non-Positive</span>
																			
                                    
                                        </a>
</div>
							
								</div>
							</div>						
		
                                            <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h3>Covid-19 Cases in Tabaco City
													            <span class="pull-right">
              <a href="print.php" class="btn btn-success btn-sm btn-flat"><span class="glyphicon glyphicon-print"></span> Print</a>
            </span>
													</h3>
                                                </div>
                                            </div>

    <div class="row">
      <!-- single canvas node to render the chart -->
      <canvas
        id="myChart"
        width="1090"
        height="400"
        aria-label="chart"
        role="img"
      ></canvas>
    </div>
    <script src="jsch/chart.js"></script>
  <!--  <script src="jsch/custom.js"></script> -->
    
  
<script>
var ctx = document.getElementById("myChart").getContext("2d");
// Creating Chart Class Object
var myChart = new Chart(ctx, {
  // Type of Chart - bar, line, pie, doughnut, radar, polarArea
  type: "bar",

  // The data for our dataset
  data: {
    // Data Labels
    labels: ["Agnas", "Bacolod", "Bangkilingan", "Bantayan", "Baranghawon", "Basagan","Basud (Poblacion)",

"Bogñabong",

"Bombon (Poblacion)",

"Bonot",

"San Isidro (Boring)",

"Buang",

"Buhian",

"Cabagñan",

"Cobo",

"Comon",

"Cormidal",

"Divino Rostro (Poblacion)",

"Fatima",

"Guinobat",

"Hacienda (San Miguel Island)",

"Magapo",

"Mariroc",

"Matagbac",

"Oras",

"Oson",

"Panal",

"Pawa",

"Pinagbobong",

"Quinale Cabasan (Poblacion)",

"Quinastillojan",

"Rawis (San Miguel Island)",

"Sagurong (San Miguel Island)",

"Salvacion",

"San Antonio",

"San Carlos",

"San Juan (Poblacion)",

"San Lorenzo",

"San Ramon",

"San Roque",

"San Vicente",

"Santo Cristo (Poblacion)",

"Sua-Igot",

"Tabiguian",

"Tagas",

"Tayhi (Poblacion)",

"Visita (San Miguel Island)"
],

    datasets: [
      // Data Set 1
      {
        //  Chart Label
        label: "Covid-19 Cases",

        // Actual Data
               data: [<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Agnas' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total3=$query->rowCount();
?>
                                        <?php echo htmlentities($total3);?>,
										<?php
$sql2 ="SELECT BrgName, Status from tblrecord WHERE BrgName='Bacolod' and Status='Positive' ";
$query2 = $dbh -> prepare($sql2);
$query2->execute();
$results2=$query->fetchAll(PDO::FETCH_OBJ);
$total2=$query2->rowCount();
?>
                                        <?php echo htmlentities($total2);?>,
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Bangkilingan' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>,
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Bantayan' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Baranghawon' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Basagan' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>,
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Basud (Poblacion)' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Bogñabong' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Bombon (Poblacion)' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Bonot' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='San Isidro (Boring)' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Buang' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>,
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Buhian' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Cabagñan' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Cobo' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Comon' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Cormidal' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Divino Rostro (Poblacion)' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>,
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Fatima' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Guinobat' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Hacienda (San Miguel Island)' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Magapo' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Mariroc' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Matagbac' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>,
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Oras' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Oson' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Panal' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Pawa' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Pinagbobong' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Quinale Cabasan (Poblacion)' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Quinastillojan' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Rawis (San Miguel Island)' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Sagurong (San Miguel Island)' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Salvacion' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																				<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='San Antonio' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																														<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='San Carlos' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>,
																														<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='San Juan (Poblacion)' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																														<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='San Lorenzo' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																														<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='San Ramon' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																														<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='San Roque' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																														<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='San Vicente' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>, 
																														<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Santo Cristo (Poblacion)' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>,
																														<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Sua-Igot' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>,
																														<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Tabiguian' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>,
																														<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Tagas' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>,
																														<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Tayhi (Poblacion)' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>,
																														<?php
$sql ="SELECT BrgName, Status from tblrecord WHERE BrgName='Visita (San Miguel Island)' and Status='Positive' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$total1=$query->rowCount();
?>
                                        <?php echo htmlentities($total1);?>],
        // Background Color
        backgroundColor: [
          "red",
           "red",
           "red",
           "red",
           "red",
           "red",
          "red",
           "red",
           "red",
           "red",
           "red",
           "red",
          "red",
           "red",
           "red",
           "red",
           "red",
           "red",
          "red",
           "red",
           "red",
           "red",
           "red",
           "red",
          "red",
           "red",
           "red",
           "red",
           "red",
           "red",
          "red",
           "red",
           "red",
           "red",
           "red",
           "red",
          "red",
           "red",
           "red",
           "red",
           "red",
           "red",
          "red",
           "red",
           "red",
           "red",
           "red",
	   
        ],

        // Border Color
        borderColor: [
          "rgba(255, 99, 132, 1)",
          "rgba(54, 162, 235, 1)",
          "rgba(255, 206, 86, 1)",
          "rgba(75, 192, 192, 1)",
          "rgba(153, 102, 255, 1)",
          "rgba(255, 159, 64, 1)",

        ],

        // Border Width
        borderWidth: 1,
      },

      // Data Set 2
      // {
      //   //  Chart Label
      //   label: "Framework",

      //   // Actual Data
      //   data: [10, 8, 3, 7, 8, 9],

      //   // Background Color
      //   backgroundColor: [
      //     "rgba(255, 97, 132, 0.2)",
      //     "rgba(54, 16, 235, 0.2)",
      //     "rgba(255, 26, 86, 0.2)",
      //     "rgba(75, 12, 192, 0.2)",
      //     "rgba(153, 2, 255, 0.2)",
      //     "rgba(255, 19, 64, 0.2)",
      //   ],
      // },
    ],
  },

  // Configuration options go here
  options: {
    // Set Responsiveness By Default Its True
    // When Its True Canvas Width Height won't work
    responsive: false,

    // Set Padding
    layout: {
      padding: {
        left: 50,
        right: 0,
        top: 0,
        bottom: 0,
      },
    },

    // Configure ToolTips
    tooltips: {
      enabled: true, // Enable/Disable ToolTip By Default Its True
      backgroundColor: "red", // Set Tooltip Background Color
      titleFontFamily: "Comic Sans MS", // Set Tooltip Title Font Family
      titleFontSize: 30, // Set Tooltip Font Size
      titleFontStyle: "bold italic",
      titleFontColor: "yellow",
      titleAlign: "center",
      titleSpacing: 3,
      titleMarginBottom: 50,
      bodyFontFamily: "Comic Sans MS",
      bodyFontSize: 20,
      bodyFontStyle: "italic",
      bodyFontColor: "black",
      bodyAlign: "center",
      bodySpacing: 3,
    },

    // Custom Chart Title

    // Legends Configuration
    legend: {
      display: true,
      position: "bottom", // top left bottom right
      align: "end", // start end center
      labels: {
        fontColor: "red",
        fontSize: 16,
        boxWidth: 20,
      },
    },



    // We have Three Events - events which take string array, onHover and Onclick which take function
    // Example of events
    // This chart will not respond to mousemove, etc
    // mousemove, mouseout, click, touchstart, touchmove
    // events: ["click"],

    // onClick Example
    // onClick: function () {
    //   console.log("On Click");
    // },

    // onHover Example - It will work
    // onHover: function () {
    //   console.log("On Hover");
    // },
  },
});
</script>		


							
                        </section>
                        <!-- /.section -->
						<!--
  <div id="columnchart_values" style="width: auto; height: auto;">
  <script type="text/javascript">
 google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ["Element", "Density", { role: "style" } ],
        ["Copper", 8.94, "#b87333"],
        ["Silver", 10.49, "silver"],
        ["Gold", 19.30, "gold"],
        ["Platinum", 21.45, "color: #e5e4e2"]
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "Density of Precious Metals, in g/cm^3",
        width: 600,
        height: 400,
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
      chart.draw(view, options);
  }
  </script>
</div>		-->	


		
                    </div>
                    <!-- /.main-page -->


                </div>
                <!-- /.content-container -->
            </div>
            <!-- /.content-wrapper -->

        </div>
        <!-- /.main-wrapper -->

        <!-- ========== COMMON JS FILES ========== -->
        <script src="js/jquery/jquery-2.2.4.min.js"></script>
        <script src="js/jquery-ui/jquery-ui.min.js"></script>
        <script src="js/bootstrap/bootstrap.min.js"></script>
        <script src="js/pace/pace.min.js"></script>
        <script src="js/lobipanel/lobipanel.min.js"></script>
        <script src="js/iscroll/iscroll.js"></script>

        <!-- ========== PAGE JS FILES ========== -->
        <script src="js/prism/prism.js"></script>
        <script src="js/waypoint/waypoints.min.js"></script>
        <script src="js/counterUp/jquery.counterup.min.js"></script>
        <script src="js/amcharts/amcharts.js"></script>
        <script src="js/amcharts/serial.js"></script>
        <script src="js/amcharts/plugins/export/export.min.js"></script>
        <link rel="stylesheet" href="js/amcharts/plugins/export/export.css" type="text/css" media="all" />
        <script src="js/amcharts/themes/light.js"></script>
        <script src="js/toastr/toastr.min.js"></script>
        <script src="js/icheck/icheck.min.js"></script>

        <!-- ========== THEME JS ========== -->
        <script src="js/main.js"></script>
        <script src="js/production-chart.js"></script>
        <script src="js/traffic-chart.js"></script>
        <script src="js/task-list.js"></script>
		<script src="jps/jquery-3.2.1.min.js"></script>
		<script src="jsp/bootstrap.js"></script>
        <script>
            $(function(){

                // Counter for dashboard stats
                $('.counter').counterUp({
                    delay: 10,
                    time: 1000
                });

                // Welcome notification
                toastr.options = {
                  "closeButton": true,
                  "debug": false,
                  "newestOnTop": false,
                  "progressBar": false,
                  "positionClass": "toast-top-right",
                  "preventDuplicates": false,
                  "onclick": null,
                  "showDuration": "300",
                  "hideDuration": "1000",
                  "timeOut": "5000",
                  "extendedTimeOut": "1000",
                  "showEasing": "swing",
                  "hideEasing": "linear",
                  "showMethod": "fadeIn",
                  "hideMethod": "fadeOut"
                }
                toastr["success"]( "Tabaco City Covid-19 Recording System!");

            });
        </script>
		
		
    </body>

    <div class="foot"><footer>

</footer> </div>

<style> .foot{text-align: center; */}</style>
</html>
<?php } ?>
