<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{

$stid=intval($_GET['stid']);

if(isset($_POST['submit']))
{
$recordfname=$_POST['firstname'];
$recordmname=$_POST['middlename'];
$recordlname=$_POST['lastname']; 
$gender=$_POST['gender']; 
$contactnum=$_POST['contnum1']; 
$brgname=$_POST['brg']; 
$dob=$_POST['dob'];
$doq=$_POST['doq'];  
$status=$_POST['status'];
$cont_person=$_POST['cont_person'];
$placevisited=$_POST['placevisited'];
$vaccinated=$_POST['vaccinated'];
$variant=$_POST['variant'];
$sql="update tblrecord set RecordFname=:recordfname,RecordMname=:recordmname,RecordLname=:recordlname,Gender=:gender,ContactNum=:contactnum,DOB=:dob,DOQ=:doq,BrgName=:brgname,Status=:status,Contact_Person=:cont_person,Place_Visited=:placevisited,Vaccinated=:vaccinated,Variant=:variant where RecordId=:stid "; 
$query = $dbh->prepare($sql);
$query->bindParam(':recordfname',$recordfname,PDO::PARAM_STR);
$query->bindParam(':recordmname',$recordmname,PDO::PARAM_STR);
$query->bindParam(':recordlname',$recordlname,PDO::PARAM_STR);
$query->bindParam(':gender',$gender,PDO::PARAM_STR);
$query->bindParam(':contactnum',$contactnum,PDO::PARAM_STR);
$query->bindParam(':dob',$dob,PDO::PARAM_STR);
$query->bindParam(':doq',$doq,PDO::PARAM_STR);
$query->bindParam(':brgname',$brgname,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->bindParam(':cont_person',$cont_person,PDO::PARAM_STR);
$query->bindParam(':placevisited',$placevisited,PDO::PARAM_STR);
$query->bindParam(':vaccinated',$vaccinated,PDO::PARAM_STR);
$query->bindParam(':variant',$variant,PDO::PARAM_STR);
$query->bindParam(':stid',$stid,PDO::PARAM_STR);
$query->execute();

$msg="Success";
}


?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    	<meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Admin| Edit  </title>
        <link rel="stylesheet" href="css/bootstrap.min.css" media="screen" >
        <link rel="stylesheet" href="css/font-awesome.min.css" media="screen" >
        <link rel="stylesheet" href="css/animate-css/animate.min.css" media="screen" >
        <link rel="stylesheet" href="css/lobipanel/lobipanel.min.css" media="screen" >
        <link rel="stylesheet" href="css/prism/prism.css" media="screen" >
        <link rel="stylesheet" href="css/select2/select2.min.css" >
        <link rel="stylesheet" href="css/main.css" media="screen" >
        <script src="js/modernizr/modernizr.min.js"></script>
    </head>
    <body>
        <div class="main-wrapper">

            <!-- ========== TOP NAVBAR ========== -->
            <!-- ========== WRAPPER FOR BOTH SIDEBARS & MAIN CONTENT ========== -->
            <div class="content-wrapper">
                <div class="content-container">

                    <!-- ========== LEFT SIDEBAR ========== -->

                    <!-- /.left-sidebar -->

                    <div class="main-page">

                     <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title">Update Record</h2>
                                
                                </div>
                                
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->

                                <div class="col-md-6">
									<a href="manage-pui.php" class="btn btn-success btn-sm btn-flat" align="right">Back to PUI List</a>

                             

                            <!-- /.row -->
                        </div>
                        <div class="container-fluid">
                           
                        <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h5>Fill the info</h5>
                                                </div>
                                            </div>
                                            <div class="panel-body">
<?php if($msg){?>
<div class="alert alert-success left-icon-alert" role="alert">
 <strong>Well done!</strong><?php echo htmlentities($msg); ?>
 </div><?php } 
else if($error){?>
    <div class="alert alert-danger left-icon-alert" role="alert">
                                            <strong>Oh snap!</strong> <?php echo htmlentities($error); ?>
                                        </div>
                                        <?php } ?>
                                                <form class="form-horizontal" method="post">
<?php 

$sql = "SELECT tblrecord.RecordFname,tblrecord.RecordMname,tblrecord.RecordLname,tblrecord.Gender,tblrecord.ContactNum,tblrecord.DOB,tblrecord.DOQ,tblrecord.Status,tblrecord.ContactNum,tblrecord.BrgName,tblrecord.Contact_Person,tblrecord.Place_Visited,tblrecord.Vaccinated,tblrecord.Variant from tblrecord where tblrecord.RecordId=:stid";
$query = $dbh->prepare($sql);
$query->bindParam(':stid',$stid,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{  ?>


<div class="form-group">
<label for="default" class="col-sm-2 control-label">First Name</label>
<div class="col-sm-10">
<input type="text" name="firstname" class="form-control" id="firstname" value="<?php echo htmlentities($result->RecordFname)?>" required="required" autocomplete="off">
</div>
</div>

<div class="form-group">
<label for="default" class="col-sm-2 control-label">Middle Name</label>
<div class="col-sm-10">
<input type="text" name="middlename" class="form-control" id="middlename" value="<?php echo htmlentities($result->RecordMname)?>" required="required" autocomplete="off">
</div>
</div>

<div class="form-group">
<label for="default" class="col-sm-2 control-label">Last Name</label>
<div class="col-sm-10">
<input type="text" name="lastname" class="form-control" id="lastname" value="<?php echo htmlentities($result->RecordLname)?>" required="required" autocomplete="off">
</div>
</div>

<div class="form-group">
<label for="default" class="col-sm-2 control-label">Gender</label>
<div class="col-sm-10">
<?php  $gndr=$result->Gender;
if($gndr=="Male")
{
?>
<input type="radio" name="gender" value="Male" required="required" checked>Male 
<input type="radio" name="gender" value="Female" required="required">Female 
<?php }?>
<?php  
if($gndr=="Female")
{
?>
<input type="radio" name="gender" value="Male" required="required" >Male 
<input type="radio" name="gender" value="Female" required="required" checked>Female 
<?php }?>


</div>
</div>


<div class="form-group">
<label for="default" class="col-sm-2 control-label">Contact Number</label>
<div class="col-sm-10">
<input type="text" onkeypress="return isNumberKey(event)" name="contnum1" class="form-control" id="contnum1" value="<?php echo htmlentities($result->ContactNum)?>" required="required" maxlength = "11" autocomplete="off">
</div>
</div>

<script>
function isNumberKey(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode
	if (charCode > 31 && (charCode < 48 || charCode > 57))
	return false;

	return true;
}
</script>



<div class="form-group">
               <label for="date" class="col-sm-2 control-label">Date of Birth</label>
              <div class="col-sm-10">
               <input type="date" name="dob" class="form-control" value="<?php echo htmlentities($result->DOB)?>" id="date">
              </div>
</div>

<div class="form-group">
               <label for="date" class="col-sm-2 control-label">Date Quarantined</label>
              <div class="col-sm-10">
               <input type="date" name="doq" class="form-control" value="<?php echo htmlentities($result->DOQ)?>" id="date">
              </div>
</div>




<div class="form-group">
					<label for="default" class="col-sm-2 control-label">Place Visited</label>
							<div class="col-sm-10">
								<textarea rows="3" cols="30" type="text" name="placevisited" class="form-control" id="placevisited" value="<?php echo htmlentities($result->Place_Visited)?>" autocomplete="off"><?php echo htmlentities($result->Place_Visited)?></textarea>
							</div>
</div>


<div class="form-group">
					<label for="default" class="col-sm-2 control-label">Closed Contact Person</label>
							<div class="col-sm-10">
								<textarea rows="3" cols="30" type="text" name="cont_person" class="form-control" id="cont_person" value="<?php echo htmlentities($result->Contact_Person)?>" autocomplete="off"><?php echo htmlentities($result->Contact_Person)?></textarea>
							</div>
</div>


<div class="form-group">
<label for="default" class="col-sm-2 control-label">Vaccinated</label>
<div class="col-sm-10">
<?php  $vacc=$result->Vaccinated;
if($vacc=="Yes")
{
?>
<input type="radio" name="vaccinated" value="Yes" required="required" checked>Yes 
<input type="radio" name="vaccinated" value="No" required="required">No 
<?php }?>
<?php  
if($vacc=="No")
{
?>
<input type="radio" name="vaccinated" value="Yes" required="required">Yes 
<input type="radio" name="vaccinated" value="No" required="required" checked>No 
<?php }?>
<?php  
if($vacc=="")
{
?>
<input type="radio" name="vaccinated" value="Yes" required="required">Yes 
<input type="radio" name="vaccinated" value="No" required="required">No 
<?php }?>

</div>
</div>





 <!----------------------------------------------------------------------------------------->   

                                                    <div class="form-group">
                                                    <label for="default" class="col-sm-2 control-label">Resident</label>
                                                    <div class="col-sm-10">
 <select name="brg" class="form-control" id="default" ">
<option><?php echo htmlentities($result->BrgName)?></option>
<?php $sql = "SELECT * from tblclasses";
$query = $dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
foreach($results as $result)
{  ?>
<option value="<?php echo htmlentities($result->BaranggayName);?>"><?php echo htmlentities($result->BaranggayName); ?></option>
<?php }} ?>
 </select>
                                                        </div>
                                                    </div>


<?php 

$sqlr = "SELECT tblrecord.Status from tblrecord where tblrecord.RecordId=:stid";   
$queryr = $dbh->prepare($sqlr);
$queryr->bindParam(':stid',$stid,PDO::PARAM_STR);
$queryr->execute();
$resultsr=$queryr->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($resultsr as $resultr)
{  ?>


 
					<div class="form-group">
					<label for="default" class="col-sm-2 control-label">Status</label>
					<div class="col-sm-10">
					<select id="ddlPassport" onchange="ShowHideDiv()" name="status" class="form-control" required="required" autocomplete="off">
					<option><?php echo htmlentities($resultr->Status)?></option>                                        
					<option value="Positive">Positive</option>
					<option value="Non-Positive">Non-Positive</option>
					</select>
					</div>
					</div>

 <?php }} ?>  
<!----------------------------------------------------------------------------------------->



                         


<?php }} ?>   

    <script type="text/javascript">
        function ShowHideDiv() {
            var ddlPassport = document.getElementById("ddlPassport");
            var dvPassport = document.getElementById("dvPassport");
            dvPassport.style.display = ddlPassport.value == "Positive" ? "block" : "none";
        }
    </script>													
				
				
				
                                                    <div class="form-group">
    <div id="dvPassport" style="display: none">
					<label for="default" class="col-sm-2 control-label">Covid-19 Variant</label>
					<div class="col-sm-10">
					<select name="variant" class="form-control" autocomplete="off">
					<option value="">Select Variant</option>                                          
					<option value="Alpha">Alpha</option>
					<option value="Beta">Beta</option>
					<option value="Gamma">Gamma</option>
					<option value="Delta">Delta</option>
					</select>
					</div>
    </div>
   
                                                    </div>				
				

							
                                                    <div class="form-group">
                                                        <div class="col-sm-offset-2 col-sm-10">
                                                            <button type="submit" name="submit" class="btn btn-warning">Update</button>
                                                        </div>
                                                    </div>
                                                </form>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-12 -->
                                </div>
                    </div>
                </div>
                <!-- /.content-container -->
            </div>
            <!-- /.content-wrapper -->
        </div>
        <!-- /.main-wrapper -->
        <script src="js/jquery/jquery-2.2.4.min.js"></script>
        <script src="js/bootstrap/bootstrap.min.js"></script>
        <script src="js/pace/pace.min.js"></script>
        <script src="js/lobipanel/lobipanel.min.js"></script>
        <script src="js/iscroll/iscroll.js"></script>
        <script src="js/prism/prism.js"></script>
        <script src="js/select2/select2.min.js"></script>
        <script src="js/main.js"></script>
        <script>
            $(function($) {
                $(".js-states").select2();
                $(".js-states-limit").select2({
                    maximumSelectionLength: 2
                });
                $(".js-states-hide").select2({
                    minimumResultsForSearch: Infinity
                });
            });
        </script>
    </body>
</html>
<?PHP } ?>
