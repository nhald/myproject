  <nav class="navbar top-navbar bg-white box-shadow">
            	<div class="container-fluid">
                    <div class="row">
                        <div class="navbar-header no-padding">
                                <div class="col-md-6">
									<a href="dashboard.php" class="btn btn-success btn-sm btn-flat" align="right">Dashboard</a>
                                </div>
                		</div>
                        <!-- /.navbar-header -->

                		<!-- /.navbar-collapse -->
                    </div>
                    <!-- /.row -->
            	</div>
            	<!-- /.container-fluid -->
            </nav>
