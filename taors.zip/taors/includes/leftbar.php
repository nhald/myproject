<div class="left-sidebar bg-black-300 box-shadow ">
                        <div class="sidebar-content">
                            <div class="user-info closed">
                                <img src="http://placehold.it/90/c2c2c2?text=User" alt="John Doe" class="img-circle profile-img">
                                <h6 class="title">John Doe</h6>
                                <small class="info">PHP Developer</small>
                            </div>
                            <!-- /.user-info -->

                            <div class="sidebar-nav">
                                <ul class="side-nav color-gray">
                                    <li class="nav-header">
                                        <span class="">Main Category</span>
                                    </li>
                                    <li>
                                        <a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span> </a>
                                     
                                    </li>
									
									

   <li>
                                        <a href="add-record.php"><i class="fa fa-users"></i> <span>Add Records</span></a>
                                           
                                    </li>
									
									
									
									
                                    <li class="nav-header">
                                        <span class="">Records</span>
                                    </li>									

   <li class="has-children">
                                        <a href="#"><i class="fa fa-users"></i> <span>Person Under Invetigation</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <!--<li><a href="add-record.php"><i class="fa fa-bars"></i> <span>Add Records</span></a></li>-->
                                            <li><a href="manage-pui.php"><i class="fa fa fa-server"></i> <span>Manage PUI Records</span></a></li> 
                                           
                                        </ul>
                                    </li>
								
								
									

   <li class="has-children">
                                        <a href="#"><i class="fa fa-users"></i> <span>Person Under Monitoring</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <!--<li><a href="add-record.php"><i class="fa fa-bars"></i> <span>Add Records</span></a></li> -->
                                            <li><a href="manage-pum.php"><i class="fa fa fa-server"></i> <span>Manage PUM Records</span></a></li>
                                           
                                        </ul>
                                    </li>		



   <li class="has-children">
                                        <a href="#"><i class="fa fa-users"></i> <span>Person w/ Covid-19</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <!--<li><a href="add-record.php"><i class="fa fa-bars"></i> <span>Add Records</span></a></li> -->
                                            <li><a href="manage-pwcovid.php"><i class="fa fa fa-server"></i> <span>Manage PwCovid-19 Records</span></a></li>
                                           
                                        </ul>
                                    </li>											
								
   <li class="has-children">
                                        <a href="#"><i class="fa fa-users"></i> <span>Recovered</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <!--<li><a href="add-record.php"><i class="fa fa-bars"></i> <span>Add Records</span></a></li> -->
                                            <li><a href="manage-preco.php"><i class="fa fa fa-server"></i> <span>Manage Recovered Records</span></a></li>
                                           
                                        </ul>
                                    </li>

   <li class="has-children">
                                        <a href="#"><i class="fa fa-users"></i> <span>Total Deaths</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <!--<li><a href="add-record.php"><i class="fa fa-bars"></i> <span>Add Records</span></a></li> -->
                                            <li><a href="manage-pdeath.php"><i class="fa fa fa-server"></i> <span>Manage Deaths Records</span></a></li>
                                           
                                        </ul>
                                    </li>	
                                    <li class="nav-header">
                                        <span class="">Print Covid-19 Cases</span>
                                    </li>											
                                        <li><a href="print.php"><i class="fa fa-file-text"></i> <span>Print</span></a></li>
								
                      <script>
      // The function below will start the confirmation dialog
      function confirmAction() {
        let confirmAction = confirm("Are you sure you want to logout?");
        if (confirmAction) {
          document.location = 'logout.php';;
        } else {
          
        }
      }
    </script>   									
                                    <li class="nav-header">
                                        <span class="">Admin</span>
                                    </li>									
<li class="has-children">

                                        <li><a href="change-password.php"><i class="fa fa fa-server"></i> <span> Admin Change Password</span></a></li>
                                           
                                    </li> 
							
<li class="has-children">

                                        <li onclick="confirmAction()"><a href="#"><i class="fa fa fa-server"></i> <span>Logout</span></a></li>
                                           
                                    </li>									
									
                            </div>
                            <!-- /.sidebar-nav -->
                        </div>
                        <!-- /.sidebar-content -->
                    </div>