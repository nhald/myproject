<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$dbname = "taors";
$mysqli = new mysqli($host, $dbuser, $dbpass, $dbname);

?>